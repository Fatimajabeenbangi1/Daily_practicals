/* How do you count a number of vowels and consonants in a given string? */

public class CountVowelsConsonants {
    public static void main(String[] args) {
        // Input string to be processed
        String input = "Hello World";
        
        // Variables to count vowels and consonants
        int vowelCount = 0;
        int consonantCount = 0;
        
        // Convert input string to lowercase to handle both cases of vowels
        input = input.toLowerCase();
        
        // Loop through each character in the string
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            
            // Check if the character is an alphabet letter (a-z)
            if (ch >= 'a' && ch <= 'z') {
                // Check if the character is a vowel
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                    vowelCount++; // Increment vowel count
                } else {
                    consonantCount++; // Increment consonant count
                }
            }
            // Ignore non-alphabet characters like spaces, punctuation, etc.
        }
        
        // Output the counts of vowels and consonants
        System.out.println("Number of vowels: " + vowelCount);
        System.out.println("Number of consonants: " + consonantCount);
    }
}

/* Output
Number of vowels: 3
Number of consonants: 7
*/