/* Write a method that takes a String and returns a String of the same length containing the 'X' character in all positions except the last 4 positions. The characters in the last 4 positions must be the same as in the original string. For example, if the argument is

"12345678", the return value should be "XXXX5678". */

// Define a public class named Main
public class ABC {
    // Define the main method, which serves as the entry point of the program
    public static void main(String[] args) {
        // Initialize a string variable named original with value "12345678"
        String original = "12345678";
        
        // Call the maskString method with the original string and store the result in masked
        String masked = maskString(original);
        
        // Print the masked string to the console
        System.out.println(masked); // Output: XXXX5678
    }
    
    // Define a static method named maskString that takes a String input and returns a String
    public static String maskString(String input) {
        // Check if the input string is null or has fewer than 4 characters
        if (input == null || input.length() < 4) {
            return ""; // Return an empty string or handle the error as needed
        }
        
        // Determine the length of the input string
        int length = input.length();
        
        // Calculate the index from where 'X' characters will start (excluding the last 4 characters)
        int endIndex = length - 4;
        
        // Create a StringBuilder object to build the masked string efficiently
        StringBuilder maskedString = new StringBuilder();
        
        // Append 'X' characters for all positions up to endIndex
        for (int i = 0; i < endIndex; i++) {
            maskedString.append('X');
        }
        
        // Append the last 4 characters of the original input string
        maskedString.append(input.substring(endIndex));
        
        // Convert the StringBuilder object to a regular String and return it
        return maskedString.toString();
    }
}

/* Output

XXXX5678
*/