*/How to print duplicate characters from the String?*/

public class FindDuplicateCharacters {

    public static void main(String[] args) {
        String str = "programming";
        printDuplicateCharacters(str); // Call method to print duplicate characters
    }

    // Method to print duplicate characters in a string
    public static void printDuplicateCharacters(String str) {
        // Create an array to count occurrences of each character (ASCII characters)
        int[] count = new int[256]; // Each index represents an ASCII character code

        // Convert the string to a char array
        char[] charArray = str.toCharArray();

        // Count occurrences of each character in the string
        for (int i = 0; i < charArray.length; i++) {
            count[charArray[i]]++; // Increment count at the index corresponding to character code
        }

        // Print characters with count > 1 (indicating duplicates)
        System.out.println("Duplicate characters in the string '" + str + "' are:");
        for (int i = 0; i < count.length; i++) {
            if (count[i] > 1) {
                System.out.println((char) i + ": " + count[i] + " times"); // Convert index back to char and print count
            }
        }
    }
}


/*Output
Duplicate characters in the string 'programming' are:
g: 2 times
m: 2 times
r: 2 times
*/