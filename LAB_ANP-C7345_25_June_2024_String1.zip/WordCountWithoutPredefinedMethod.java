/* Write a Java Program to count the number of words in a String without using the Predefined method? */

public class WordCountWithoutPredefinedMethod {

    public static void main(String[] args) {
        // Input string
        String input = "Hello World! This is a test string.";
        
        // Count words using our custom method
        int wordCount = countWords(input);
        
        // Output the result
        System.out.println("Number of words in the string: " + wordCount);
    }

    public static int countWords(String str) {
        int count = 0;
        boolean word = false;  // to track if we are inside a word
        
        // Loop through each character of the string
        for (int i = 0; i < str.length(); i++) {
            // Check if the current character is a whitespace or punctuation
            if (str.charAt(i) == ' ' || str.charAt(i) == '\n' || str.charAt(i) == '\t' || str.charAt(i) == '\r') {
                word = false;  // if we encounter a whitespace, mark that we are outside a word
            } else if (!word) {
                // if we were not inside a word and we encounter a character, it means a new word starts
                word = true;
                count++;  // increment word count
            }
        }
        
        return count;  // return the total count of words in the string
    }
}

/* Output

Number of words in the string: 7
*/